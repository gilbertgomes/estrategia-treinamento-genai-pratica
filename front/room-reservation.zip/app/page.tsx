import RoomReservationForm from "../room-reservation-form"

export default function Page() {
  return (
    <main>
      <RoomReservationForm />
    </main>
  )
}
